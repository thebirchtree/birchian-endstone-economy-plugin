"""Pure-Python storage layer (no Endstone imports) for accounts and sell prices."""

from __future__ import annotations

import json
import math
import os
from pathlib import Path

MAX_BALANCE = 1_000_000_000_000.0

DEFAULT_PRICES: dict[str, float] = {
    # ores & minerals
    "minecraft:coal": 5, "minecraft:charcoal": 4, "minecraft:raw_copper": 4,
    "minecraft:copper_ingot": 6, "minecraft:raw_iron": 8, "minecraft:iron_ingot": 12,
    "minecraft:raw_gold": 14, "minecraft:gold_ingot": 20, "minecraft:gold_nugget": 2,
    "minecraft:iron_nugget": 1.5, "minecraft:redstone": 4, "minecraft:lapis_lazuli": 5,
    "minecraft:quartz": 6, "minecraft:amethyst_shard": 8, "minecraft:diamond": 150,
    "minecraft:emerald": 100, "minecraft:netherite_scrap": 400, "minecraft:netherite_ingot": 2000,
    # blocks
    "minecraft:cobblestone": 0.5, "minecraft:stone": 0.75, "minecraft:deepslate": 0.6,
    "minecraft:dirt": 0.2, "minecraft:sand": 0.5, "minecraft:gravel": 0.4,
    "minecraft:glass": 1, "minecraft:obsidian": 20, "minecraft:netherrack": 0.2,
    "minecraft:end_stone": 1.5, "minecraft:clay_ball": 1, "minecraft:brick": 2,
    # wood
    "minecraft:oak_log": 2, "minecraft:spruce_log": 2, "minecraft:birch_log": 2,
    "minecraft:jungle_log": 2.5, "minecraft:acacia_log": 2, "minecraft:dark_oak_log": 2,
    "minecraft:cherry_log": 2.5, "minecraft:mangrove_log": 2.5, "minecraft:stick": 0.25,
    # farming
    "minecraft:wheat": 2, "minecraft:carrot": 2, "minecraft:potato": 2, "minecraft:beetroot": 2,
    "minecraft:sugar_cane": 1.5, "minecraft:melon_slice": 1, "minecraft:pumpkin": 4,
    "minecraft:cocoa_beans": 3, "minecraft:bamboo": 0.5, "minecraft:cactus": 1,
    "minecraft:sweet_berries": 1.5, "minecraft:nether_wart": 4, "minecraft:kelp": 0.5,
    # mob drops
    "minecraft:rotten_flesh": 0.5, "minecraft:bone": 2, "minecraft:string": 2,
    "minecraft:spider_eye": 2, "minecraft:gunpowder": 5, "minecraft:ender_pearl": 25,
    "minecraft:blaze_rod": 20, "minecraft:ghast_tear": 40, "minecraft:slime_ball": 6,
    "minecraft:leather": 4, "minecraft:feather": 1, "minecraft:ink_sac": 3,
    "minecraft:prismarine_shard": 5, "minecraft:nautilus_shell": 60,
    "minecraft:shulker_shell": 120, "minecraft:nether_star": 5000,
    # food
    "minecraft:beef": 3, "minecraft:cooked_beef": 6, "minecraft:porkchop": 3,
    "minecraft:cooked_porkchop": 6, "minecraft:chicken": 2, "minecraft:cooked_chicken": 4,
    "minecraft:cod": 2, "minecraft:salmon": 2.5, "minecraft:egg": 1,
}

# Buy prices (per item) grouped by shop category. Keep these well above the sell
# prices in DEFAULT_PRICES so players can't profit by buying and re-selling.
DEFAULT_SHOP: dict[str, dict[str, float]] = {
    "Building Blocks": {
        "minecraft:cobblestone": 3, "minecraft:stone": 4, "minecraft:dirt": 1,
        "minecraft:sand": 3, "minecraft:gravel": 3, "minecraft:glass": 6,
        "minecraft:oak_planks": 4, "minecraft:spruce_planks": 4, "minecraft:birch_planks": 4,
        "minecraft:oak_log": 10, "minecraft:spruce_log": 10, "minecraft:birch_log": 10,
        "minecraft:white_wool": 12, "minecraft:obsidian": 120, "minecraft:bookshelf": 60,
    },
    "Food": {
        "minecraft:bread": 10, "minecraft:apple": 8, "minecraft:golden_apple": 250,
        "minecraft:cooked_beef": 25, "minecraft:cooked_porkchop": 25,
        "minecraft:cooked_chicken": 20, "minecraft:cooked_salmon": 20,
        "minecraft:baked_potato": 12, "minecraft:pumpkin_pie": 18, "minecraft:cake": 60,
    },
    "Farming": {
        "minecraft:wheat_seeds": 4, "minecraft:beetroot_seeds": 4,
        "minecraft:pumpkin_seeds": 6, "minecraft:melon_seeds": 6,
        "minecraft:carrot": 10, "minecraft:potato": 10, "minecraft:bone_meal": 12,
        "minecraft:oak_sapling": 15, "minecraft:spruce_sapling": 15,
        "minecraft:birch_sapling": 15,
    },
    "Ores & Minerals": {
        "minecraft:coal": 20, "minecraft:copper_ingot": 25, "minecraft:iron_ingot": 50,
        "minecraft:gold_ingot": 90, "minecraft:redstone": 18, "minecraft:lapis_lazuli": 22,
        "minecraft:quartz": 25, "minecraft:diamond": 700, "minecraft:emerald": 450,
    },
    "Tools & Gear": {
        "minecraft:iron_pickaxe": 220, "minecraft:iron_axe": 220,
        "minecraft:iron_shovel": 120, "minecraft:iron_sword": 200,
        "minecraft:diamond_pickaxe": 2200, "minecraft:diamond_axe": 2200,
        "minecraft:diamond_shovel": 1000, "minecraft:diamond_sword": 1800,
        "minecraft:bow": 80, "minecraft:arrow": 6, "minecraft:shield": 90,
        "minecraft:shears": 60, "minecraft:fishing_rod": 50,
    },
    "Utility": {
        "minecraft:torch": 3, "minecraft:crafting_table": 15, "minecraft:furnace": 25,
        "minecraft:chest": 30, "minecraft:ladder": 4, "minecraft:bucket": 70,
        "minecraft:water_bucket": 80, "minecraft:ender_pearl": 150,
        "minecraft:experience_bottle": 120, "minecraft:name_tag": 200,
        "minecraft:saddle": 300, "minecraft:lead": 60,
    },
}


def _read_json(path: Path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return default
    except (json.JSONDecodeError, OSError):
        return default


def _write_json(path: Path, data) -> None:
    """Atomic write so a crash can't leave a half-written file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    os.replace(tmp, path)


def normalize_item_id(raw: str) -> str:
    s = raw.strip().strip('"').strip("'").lower().replace(" ", "_")
    if ":" not in s:
        s = "minecraft:" + s
    return s


def parse_amount(text: str) -> float | None:
    """Parse a money amount. Returns None for junk, NaN or infinity."""
    try:
        value = float(str(text).strip().replace(",", ""))
    except ValueError:
        return None
    if not math.isfinite(value):
        return None
    return round(value, 2)


class Accounts:
    """uuid -> {"name": str, "balance": float}, persisted to accounts.json."""

    def __init__(self, path: Path, starting_balance: float = 0.0):
        self.path = path
        self.starting_balance = starting_balance
        self._data: dict[str, dict] = {}
        self._names: dict[str, str] = {}
        self.load()

    def load(self) -> None:
        raw = _read_json(self.path, {})
        self._data = {}
        for key, entry in raw.items():
            try:
                self._data[key] = {
                    "name": str(entry.get("name", key)),
                    "balance": round(float(entry.get("balance", 0.0)), 2),
                }
            except (AttributeError, TypeError, ValueError):
                continue
        self._reindex()

    def save(self) -> None:
        _write_json(self.path, self._data)

    def _reindex(self) -> None:
        self._names = {e["name"].lower(): k for k, e in self._data.items()}

    # ---- lookups -------------------------------------------------------
    def ensure(self, key: str, name: str) -> bool:
        """Create the account if missing and keep the stored name current."""
        created = key not in self._data
        if created:
            self._data[key] = {"name": name, "balance": round(self.starting_balance, 2)}
            self._reindex()
            self._names[name.lower()] = key
            self.save()
        elif self._data[key]["name"] != name:
            self._data[key]["name"] = name
            self._reindex()
            self.save()
        return created

    def find(self, name: str) -> str | None:
        name = name.strip().strip('"').strip("'").lower()
        return self._names.get(name)

    def name_of(self, key: str) -> str:
        return self._data.get(key, {}).get("name", key)

    def balance(self, key: str) -> float:
        return self._data.get(key, {}).get("balance", 0.0)

    def has(self, key: str, amount: float) -> bool:
        return self.balance(key) + 1e-9 >= amount

    # ---- mutations -----------------------------------------------------
    def set_balance(self, key: str, amount: float) -> float:
        amount = max(0.0, min(MAX_BALANCE, round(amount, 2)))
        self._data[key]["balance"] = amount
        self.save()
        return amount

    def deposit(self, key: str, amount: float) -> float:
        return self.set_balance(key, self.balance(key) + amount)

    def withdraw(self, key: str, amount: float) -> bool:
        if not self.has(key, amount):
            return False
        self.set_balance(key, self.balance(key) - amount)
        return True

    # ---- leaderboard ---------------------------------------------------
    def top(self) -> list[tuple[str, float]]:
        rows = [(e["name"], e["balance"]) for e in self._data.values()]
        rows.sort(key=lambda r: (-r[1], r[0].lower()))
        return rows


class PriceList:
    """item id -> price per single item, loaded from prices.json."""

    def __init__(self, path: Path):
        self.path = path
        self._prices: dict[str, float] = {}
        self.load()

    def load(self) -> int:
        if not self.path.exists():
            _write_json(self.path, DEFAULT_PRICES)
        raw = _read_json(self.path, {})
        self._prices = {}
        for key, value in raw.items():
            if str(key).startswith("_"):  # allow "_comment" style keys
                continue
            try:
                price = float(value)
            except (TypeError, ValueError):
                continue
            if math.isfinite(price) and price > 0:
                self._prices[normalize_item_id(str(key))] = round(price, 2)
        return len(self._prices)

    def price(self, item_id: str) -> float | None:
        return self._prices.get(item_id)

    def __len__(self) -> int:
        return len(self._prices)


class ShopCatalog:
    """category -> {item id: buy price per item}, loaded from shop.json."""

    def __init__(self, path: Path):
        self.path = path
        self.categories: dict[str, dict[str, float]] = {}
        self.load()

    def load(self) -> int:
        """(Re)load shop.json, writing the defaults on first run. Returns the item count."""
        if not self.path.exists():
            _write_json(self.path, DEFAULT_SHOP)
        raw = _read_json(self.path, {})
        self.categories = {}
        for category, items in raw.items():
            if str(category).startswith("_") or not isinstance(items, dict):
                continue
            cleaned: dict[str, float] = {}
            for key, value in items.items():
                try:
                    price = float(value)
                except (TypeError, ValueError):
                    continue
                if math.isfinite(price) and price > 0:
                    cleaned[normalize_item_id(str(key))] = round(price, 2)
            if cleaned:
                self.categories[str(category)] = cleaned
        return sum(len(v) for v in self.categories.values())

    def items(self, category: str) -> dict[str, float]:
        return self.categories.get(category, {})

    def price(self, category: str, item_id: str) -> float | None:
        return self.categories.get(category, {}).get(item_id)
