from endstone_economy.plugin import EconomyPlugin

__all__ = ["EconomyPlugin"]
