"""Economy plugin for Endstone (Bedrock Dedicated Server).

Commands: /balance /money /mymoney /pay /baltop /sell /sellhand /sellall /sellgui /worth /shop
          /addmoney /subtractmoney /setmoney /transfermoney /ecoreload

Files (in plugins/economy/):
    accounts.json  - player balances (managed by the plugin)
    shop.json      - /shop catalog: category -> item -> buy price
    prices.json    - global sell prices, "minecraft:item_id": price_per_item
    config.json    - currency symbol, starting balance, baltop page size
"""

from __future__ import annotations

import json
from collections import defaultdict

from endstone import ColorFormat, Player
from endstone.command import Command, CommandSender
from endstone.event import PlayerJoinEvent, event_handler
from endstone.form import ActionForm, ModalForm, Slider
from endstone.inventory import ItemStack
from endstone.plugin import Plugin

from endstone_economy.economy import (
    Accounts,
    PriceList,
    ShopCatalog,
    normalize_item_id,
    parse_amount,
)

DEFAULT_SETTINGS = {
    "currency_symbol": "$",
    "starting_balance": 100.0,
    "baltop_page_size": 10,
    "shop_max_amount": 64,
}


def item_id_of(stack) -> str:
    """Return e.g. 'minecraft:diamond' for an ItemStack (works for ItemType objects or str)."""
    t = stack.type
    return str(getattr(t, "id", t))


class EconomyPlugin(Plugin):
    name = "economy"
    prefix = "Economy"
    api_version = "0.11"

    commands = {
        "balance": {
            "description": "Show your balance or another player's balance",
            "usages": ["/balance [player: str]"],
            "aliases": ["bal"],
            "permissions": ["economy.command.balance"],
        },
        "money": {
            "description": "Show your balance or another player's balance",
            "usages": ["/money [player: str]"],
            "permissions": ["economy.command.money"],
        },
        "mymoney": {
            "description": "Show your own balance",
            "usages": ["/mymoney"],
            "permissions": ["economy.command.mymoney"],
        },
        "pay": {
            "description": "Send money to another player",
            "usages": ["/pay <player: str> <amount: float>"],
            "permissions": ["economy.command.pay"],
        },
        "baltop": {
            "description": "Show the richest players",
            "usages": ["/baltop [page: int]"],
            "permissions": ["economy.command.baltop"],
        },
        "sell": {
            "description": "Sell an item from your inventory (amount or 'all')",
            "usages": ["/sell <item: str> [amount: str]"],
            "permissions": ["economy.command.sell"],
        },
        "sellhand": {
            "description": "Sell the stack you are holding (or part of it)",
            "usages": ["/sellhand [amount: int]"],
            "permissions": ["economy.command.sellhand"],
        },
        "sellall": {
            "description": "Sell every sellable item in your inventory",
            "usages": ["/sellall"],
            "permissions": ["economy.command.sellall"],
        },
        "sellgui": {
            "description": "Open the sell menu (pick items and amounts with a form)",
            "usages": ["/sellgui"],
            "permissions": ["economy.command.sellgui"],
        },
        "shop": {
            "description": "Open the shop menu to buy items",
            "usages": ["/shop"],
            "permissions": ["economy.command.shop"],
        },
        "worth": {
            "description": "Check the sell price of an item (or the one in your hand)",
            "usages": ["/worth [item: str]"],
            "permissions": ["economy.command.worth"],
        },
        "addmoney": {
            "description": "Give money to a player",
            "usages": ["/addmoney <player: str> <amount: float>"],
            "permissions": ["economy.command.addmoney"],
        },
        "subtractmoney": {
            "description": "Take money from a player",
            "usages": ["/subtractmoney <player: str> <amount: float>"],
            "permissions": ["economy.command.subtractmoney"],
        },
        "setmoney": {
            "description": "Set a player's balance",
            "usages": ["/setmoney <player: str> <amount: float>"],
            "permissions": ["economy.command.setmoney"],
        },
        "transfermoney": {
            "description": "Move money from one player's account to another",
            "usages": ["/transfermoney <from: str> <to: str> <amount: float>"],
            "permissions": ["economy.command.transfermoney"],
        },
        "ecoreload": {
            "description": "Reload prices.json and config.json",
            "usages": ["/ecoreload"],
            "permissions": ["economy.command.ecoreload"],
        },
    }

    permissions = {
        "economy.command": {
            "description": "Allow use of all economy commands",
            "default": "op",
            "children": {
                "economy.command.balance": True,
                "economy.command.money": True,
                "economy.command.mymoney": True,
                "economy.command.pay": True,
                "economy.command.baltop": True,
                "economy.command.sell": True,
                "economy.command.sellhand": True,
                "economy.command.sellall": True,
                "economy.command.sellgui": True,
                "economy.command.shop": True,
                "economy.command.worth": True,
                "economy.command.addmoney": True,
                "economy.command.subtractmoney": True,
                "economy.command.setmoney": True,
                "economy.command.transfermoney": True,
                "economy.command.ecoreload": True,
            },
        },
        # Player commands
        "economy.command.balance": {"description": "Check balances", "default": True},
        "economy.command.money": {"description": "Check balances", "default": True},
        "economy.command.mymoney": {"description": "Check own balance", "default": True},
        "economy.command.pay": {"description": "Pay other players", "default": True},
        "economy.command.baltop": {"description": "View leaderboard", "default": True},
        "economy.command.sell": {"description": "Sell items", "default": True},
        "economy.command.sellhand": {"description": "Sell held item", "default": True},
        "economy.command.sellall": {"description": "Sell whole inventory", "default": True},
        "economy.command.sellgui": {"description": "Use the sell menu", "default": True},
        "economy.command.shop": {"description": "Use the shop menu", "default": True},
        "economy.command.worth": {"description": "Check item worth", "default": True},
        # Admin commands
        "economy.command.addmoney": {"description": "Add money", "default": "op"},
        "economy.command.subtractmoney": {"description": "Subtract money", "default": "op"},
        "economy.command.setmoney": {"description": "Set money", "default": "op"},
        "economy.command.transfermoney": {"description": "Transfer money", "default": "op"},
        "economy.command.ecoreload": {"description": "Reload config", "default": "op"},
    }

    # ------------------------------------------------------------------ lifecycle
    def on_enable(self) -> None:
        self.data_folder.mkdir(parents=True, exist_ok=True)
        self.settings = self._load_settings()
        self.accounts = Accounts(
            self.data_folder / "accounts.json", float(self.settings["starting_balance"])
        )
        self.prices = PriceList(self.data_folder / "prices.json")
        self.shop = ShopCatalog(self.data_folder / "shop.json")
        self.register_events(self)
        self.logger.info(
            f"Economy enabled: {len(self.prices)} sellable items, "
            f"{sum(len(v) for v in self.shop.categories.values())} shop items, "
            f"data in {self.data_folder}"
        )

    def on_disable(self) -> None:
        if hasattr(self, "accounts"):
            self.accounts.save()

    def _load_settings(self) -> dict:
        path = self.data_folder / "config.json"
        settings = dict(DEFAULT_SETTINGS)
        try:
            with open(path, "r", encoding="utf-8") as f:
                settings.update(json.load(f))
        except FileNotFoundError:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(DEFAULT_SETTINGS, f, indent=2)
        except (json.JSONDecodeError, OSError, AttributeError):
            self.logger.warning("config.json is invalid, using defaults")
        return settings

    @event_handler
    def on_player_join(self, event: PlayerJoinEvent) -> None:
        player = event.player
        self.accounts.ensure(str(player.unique_id), player.name)

    # ------------------------------------------------------------------ helpers
    def _fmt(self, amount: float) -> str:
        return f"{self.settings['currency_symbol']}{amount:,.2f}"

    def _err(self, sender: CommandSender, msg: str) -> None:
        sender.send_error_message(msg)

    def _ok(self, sender: CommandSender, msg: str) -> None:
        sender.send_message(f"{ColorFormat.GREEN}{msg}")

    def _key(self, player: Player) -> str:
        key = str(player.unique_id)
        self.accounts.ensure(key, player.name)
        return key

    def _require_player(self, sender: CommandSender) -> Player | None:
        if isinstance(sender, Player):
            return sender
        self._err(sender, "This command can only be used by a player.")
        return None

    def _resolve(self, sender: CommandSender, name: str) -> str | None:
        key = self.accounts.find(name)
        if key is None:
            self._err(sender, f"Unknown player '{name}'. They must have joined the server at least once.")
        return key

    def _amount(self, sender: CommandSender, text: str, allow_zero: bool = False) -> float | None:
        value = parse_amount(text)
        if value is None:
            self._err(sender, f"'{text}' is not a valid amount.")
            return None
        if value < 0 or (value == 0 and not allow_zero):
            self._err(sender, "Amount must be greater than zero.")
            return None
        return value

    def _notify(self, key: str, message: str) -> None:
        online = self.server.get_player(self.accounts.name_of(key))
        if online is not None:
            online.send_message(message)

    # ------------------------------------------------------------------ dispatch
    def on_command(self, sender: CommandSender, command: Command, args: list[str]) -> bool:
        handler = getattr(self, f"_cmd_{command.name}", None)
        if handler is None:
            return False
        return handler(sender, args)

    # ------------------------------------------------------------------ balance commands
    def _cmd_balance(self, sender: CommandSender, args: list[str]) -> bool:
        if args:
            key = self._resolve(sender, args[0])
            if key is None:
                return True
            sender.send_message(
                f"{ColorFormat.GOLD}{self.accounts.name_of(key)}'s balance: "
                f"{ColorFormat.YELLOW}{self._fmt(self.accounts.balance(key))}"
            )
            return True
        player = self._require_player(sender)
        if player is None:
            return True
        sender.send_message(
            f"{ColorFormat.GOLD}Balance: "
            f"{ColorFormat.YELLOW}{self._fmt(self.accounts.balance(self._key(player)))}"
        )
        return True

    _cmd_money = _cmd_balance

    def _cmd_mymoney(self, sender: CommandSender, args: list[str]) -> bool:
        return self._cmd_balance(sender, [])

    def _cmd_baltop(self, sender: CommandSender, args: list[str]) -> bool:
        rows = self.accounts.top()
        size = max(1, int(self.settings["baltop_page_size"]))
        pages = max(1, (len(rows) + size - 1) // size)
        try:
            page = int(args[0]) if args else 1
        except ValueError:
            return False
        page = max(1, min(page, pages))
        start = (page - 1) * size
        lines = [f"{ColorFormat.GOLD}--- Top Balances ({page}/{pages}) ---"]
        for i, (name, bal) in enumerate(rows[start:start + size], start=start + 1):
            lines.append(f"{ColorFormat.YELLOW}{i}. {ColorFormat.WHITE}{name}{ColorFormat.GRAY}: "
                         f"{ColorFormat.GREEN}{self._fmt(bal)}")
        if not rows:
            lines.append(f"{ColorFormat.GRAY}No accounts yet.")
        sender.send_message("\n".join(lines))
        return True

    # ------------------------------------------------------------------ pay
    def _cmd_pay(self, sender: CommandSender, args: list[str]) -> bool:
        player = self._require_player(sender)
        if player is None:
            return True
        if len(args) < 2:
            return False
        src = self._key(player)
        dst = self._resolve(sender, args[0])
        if dst is None:
            return True
        if dst == src:
            self._err(sender, "You can't pay yourself.")
            return True
        amount = self._amount(sender, args[1])
        if amount is None:
            return True
        if not self.accounts.withdraw(src, amount):
            self._err(sender, f"Insufficient funds. You have {self._fmt(self.accounts.balance(src))}.")
            return True
        self.accounts.deposit(dst, amount)
        self._ok(sender, f"You paid {self.accounts.name_of(dst)} {self._fmt(amount)}.")
        self._notify(dst, f"{ColorFormat.GREEN}You received {self._fmt(amount)} from {player.name}.")
        return True

    # ------------------------------------------------------------------ selling
    @staticmethod
    def _clear_slot(inv, slot: int) -> None:
        try:
            inv.clear(slot)
        except TypeError:
            inv.set_item(slot, None)

    def _count_item(self, inv, item_id: str) -> int:
        total = 0
        for slot in range(inv.size):
            stack = inv.get_item(slot)
            if stack is not None and stack.amount > 0 and item_id_of(stack) == item_id:
                total += stack.amount
        return total

    def _remove_item(self, inv, item_id: str, amount: int) -> int:
        """Remove up to `amount` of an item across the inventory. Returns how many were removed."""
        remaining = amount
        for slot in range(inv.size):
            if remaining <= 0:
                break
            stack = inv.get_item(slot)
            if stack is None or stack.amount <= 0 or item_id_of(stack) != item_id:
                continue
            take = min(stack.amount, remaining)
            if take >= stack.amount:
                self._clear_slot(inv, slot)
            else:
                stack.amount = stack.amount - take
                inv.set_item(slot, stack)
            remaining -= take
        return amount - remaining

    def _sell(self, player: Player, item_id: str, amount: int | None) -> None:
        """Sell `amount` of item_id (None = everything the player has)."""
        price = self.prices.price(item_id)
        if price is None:
            self._err(player, f"{item_id} can't be sold (no price set).")
            return
        inv = player.inventory
        have = self._count_item(inv, item_id)
        if have <= 0:
            self._err(player, f"You don't have any {item_id}.")
            return
        if amount is None:
            amount = have
        if amount > have:
            self._err(player, f"You only have {have} {item_id}.")
            return
        sold = self._remove_item(inv, item_id, amount)
        earned = round(sold * price, 2)
        self.accounts.deposit(self._key(player), earned)
        player.send_message(
            f"{ColorFormat.GREEN}Sold {sold}x {item_id} for {self._fmt(earned)} "
            f"{ColorFormat.GRAY}({self._fmt(price)} each)"
        )

    def _cmd_sell(self, sender: CommandSender, args: list[str]) -> bool:
        player = self._require_player(sender)
        if player is None:
            return True
        if not args:
            return False
        item_id = normalize_item_id(args[0])
        amount: int | None = None  # default: sell all of that item
        if len(args) > 1 and args[1].lower() != "all":
            try:
                amount = int(args[1])
            except ValueError:
                self._err(sender, f"'{args[1]}' is not a valid amount (use a number or 'all').")
                return True
            if amount <= 0:
                self._err(sender, "Amount must be greater than zero.")
                return True
        self._sell(player, item_id, amount)
        return True

    def _held(self, player: Player):
        stack = player.inventory.item_in_main_hand
        if stack is None or stack.amount <= 0:
            return None
        return stack

    def _cmd_sellhand(self, sender: CommandSender, args: list[str]) -> bool:
        player = self._require_player(sender)
        if player is None:
            return True
        stack = self._held(player)
        if stack is None:
            self._err(sender, "You aren't holding anything.")
            return True
        item_id = item_id_of(stack)
        price = self.prices.price(item_id)
        if price is None:
            self._err(sender, f"{item_id} can't be sold (no price set).")
            return True
        amount = stack.amount
        if args:
            try:
                amount = int(args[0])
            except ValueError:
                return False
            if amount <= 0 or amount > stack.amount:
                self._err(sender, f"Amount must be between 1 and {stack.amount}.")
                return True
        inv = player.inventory
        slot = inv.held_item_slot
        if amount >= stack.amount:
            self._clear_slot(inv, slot)
        else:
            stack.amount = stack.amount - amount
            inv.set_item(slot, stack)
        earned = round(amount * price, 2)
        self.accounts.deposit(self._key(player), earned)
        self._ok(sender, f"Sold {amount}x {item_id} for {self._fmt(earned)} ({self._fmt(price)} each)")
        return True

    def _do_sellall(self, player: Player) -> bool:
        """Sell every sellable item. Returns True if anything was sold."""
        inv = player.inventory
        sold: dict[str, int] = defaultdict(int)
        total = 0.0
        for slot in range(inv.size):
            stack = inv.get_item(slot)
            if stack is None or stack.amount <= 0:
                continue
            item_id = item_id_of(stack)
            price = self.prices.price(item_id)
            if price is None:
                continue
            sold[item_id] += stack.amount
            total += stack.amount * price
            self._clear_slot(inv, slot)
        if not sold:
            self._err(player, "You have nothing sellable in your inventory.")
            return False
        total = round(total, 2)
        self.accounts.deposit(self._key(player), total)
        lines = [f"{ColorFormat.GREEN}Sold {sum(sold.values())} items for {self._fmt(total)}:"]
        for item_id, count in sorted(sold.items(), key=lambda kv: -kv[1] * (self.prices.price(kv[0]) or 0))[:8]:
            lines.append(f"{ColorFormat.GRAY} - {count}x {item_id}")
        if len(sold) > 8:
            lines.append(f"{ColorFormat.GRAY} ...and {len(sold) - 8} more item types")
        player.send_message("\n".join(lines))
        return True

    def _cmd_sellall(self, sender: CommandSender, args: list[str]) -> bool:
        player = self._require_player(sender)
        if player is not None:
            self._do_sellall(player)
        return True

    # ------------------------------------------------------------------ sell GUI
    @staticmethod
    def _pretty(item_id: str) -> str:
        return item_id.split(":", 1)[-1].replace("_", " ").title()

    def _sellable_summary(self, player: Player) -> dict[str, int]:
        inv = player.inventory
        summary: dict[str, int] = defaultdict(int)
        for slot in range(inv.size):
            stack = inv.get_item(slot)
            if stack is None or stack.amount <= 0:
                continue
            item_id = item_id_of(stack)
            if self.prices.price(item_id) is not None:
                summary[item_id] += stack.amount
        return summary

    def _cmd_sellgui(self, sender: CommandSender, args: list[str]) -> bool:
        player = self._require_player(sender)
        if player is not None:
            self._open_sell_menu(player)
        return True

    def _open_sell_menu(self, player: Player, announce_empty: bool = True) -> None:
        summary = self._sellable_summary(player)
        if not summary:
            if announce_empty:
                self._err(player, "You have nothing sellable in your inventory.")
            return
        rows = sorted(
            ((iid, n, n * self.prices.price(iid)) for iid, n in summary.items()),
            key=lambda r: -r[2],
        )
        total = sum(r[2] for r in rows)
        form = ActionForm(
            title="Sell Items",
            content=(
                f"Balance: {self._fmt(self.accounts.balance(self._key(player)))}\n"
                f"Sellable inventory value: {self._fmt(total)}\n\n"
                "Pick an item to sell."
            ),
        )
        form.add_button(
            f"Sell Everything\n{self._fmt(total)}",
            on_click=lambda p: self._gui_sell_all(p),
        )
        for item_id, count, worth in rows:
            form.add_button(
                f"{self._pretty(item_id)} x{count}\n{self._fmt(worth)}",
                on_click=lambda p, i=item_id: self._open_amount_form(p, i),
            )
        player.send_form(form)

    def _gui_sell_all(self, player: Player) -> None:
        self._do_sellall(player)

    def _open_amount_form(self, player: Player, item_id: str) -> None:
        price = self.prices.price(item_id)
        have = self._count_item(player.inventory, item_id)
        if price is None or have <= 0:
            self._err(player, f"You no longer have any sellable {self._pretty(item_id)}.")
            self._open_sell_menu(player, announce_empty=False)
            return
        if have == 1:  # a slider needs a range; one item is just sold directly
            self._sell(player, item_id, 1)
            self._open_sell_menu(player, announce_empty=False)
            return
        form = ModalForm(
            title=f"Sell {self._pretty(item_id)}",
            controls=[
                Slider(
                    label=(
                        f"{self._fmt(price)} each - you have {have}\n"
                        "Amount to sell"
                    ),
                    min=1,
                    max=have,
                    step=1,
                    default_value=have,
                ),
            ],
            on_submit=lambda p, data, i=item_id: self._gui_submit_amount(p, i, data),
        )
        player.send_form(form)

    def _gui_submit_amount(self, player: Player, item_id: str, data: str) -> None:
        try:
            amount = int(round(float(json.loads(data)[0])))
        except (ValueError, TypeError, IndexError, KeyError):
            self._err(player, "Invalid amount.")
            return
        if amount < 1:
            self._err(player, "Amount must be at least 1.")
            return
        self._sell(player, item_id, amount)  # re-checks the inventory, so it can't be abused
        self._open_sell_menu(player, announce_empty=False)

    # ------------------------------------------------------------------ shop GUI
    def _cmd_shop(self, sender: CommandSender, args: list[str]) -> bool:
        player = self._require_player(sender)
        if player is not None:
            self._open_shop_menu(player)
        return True

    def _open_shop_menu(self, player: Player) -> None:
        if not self.shop.categories:
            self._err(player, "The shop is empty right now.")
            return
        form = ActionForm(
            title="Shop",
            content=(
                f"Balance: {self._fmt(self.accounts.balance(self._key(player)))}\n\n"
                "Choose a category."
            ),
        )
        for category, items in self.shop.categories.items():
            form.add_button(
                f"{category}\n{len(items)} items",
                on_click=lambda p, c=category: self._open_shop_category(p, c),
            )
        player.send_form(form)

    def _open_shop_category(self, player: Player, category: str) -> None:
        items = self.shop.items(category)
        if not items:
            self._open_shop_menu(player)
            return
        form = ActionForm(
            title=category,
            content=f"Balance: {self._fmt(self.accounts.balance(self._key(player)))}",
        )
        for item_id, price in items.items():
            form.add_button(
                f"{self._pretty(item_id)}\n{self._fmt(price)} each",
                on_click=lambda p, c=category, i=item_id: self._open_buy_form(p, c, i),
            )
        form.add_button("< Back", on_click=lambda p: self._open_shop_menu(p))
        player.send_form(form)

    def _open_buy_form(self, player: Player, category: str, item_id: str) -> None:
        price = self.shop.price(category, item_id)
        if price is None:
            self._err(player, f"{self._pretty(item_id)} is no longer for sale.")
            self._open_shop_category(player, category)
            return
        balance = self.accounts.balance(self._key(player))
        max_amount = max(1, int(self.settings["shop_max_amount"]))
        affordable = min(int(balance / price + 1e-9), max_amount)
        if affordable < 1:
            self._err(player, f"You can't afford {self._pretty(item_id)} "
                              f"({self._fmt(price)} each, you have {self._fmt(balance)}).")
            self._open_shop_category(player, category)
            return
        if affordable == 1:  # a slider needs a range; one item is just bought directly
            self._buy(player, item_id, 1, price)
            self._open_shop_category(player, category)
            return
        form = ModalForm(
            title=f"Buy {self._pretty(item_id)}",
            controls=[
                Slider(
                    label=(
                        f"{self._fmt(price)} each - you can afford {affordable}\n"
                        "Amount to buy"
                    ),
                    min=1,
                    max=affordable,
                    step=1,
                    default_value=1,
                ),
            ],
            on_submit=lambda p, data, c=category, i=item_id: self._gui_submit_buy(p, c, i, data),
        )
        player.send_form(form)

    def _gui_submit_buy(self, player: Player, category: str, item_id: str, data: str) -> None:
        try:
            amount = int(round(float(json.loads(data)[0])))
        except (ValueError, TypeError, IndexError, KeyError):
            self._err(player, "Invalid amount.")
            return
        max_amount = max(1, int(self.settings["shop_max_amount"]))
        if amount < 1 or amount > max_amount:
            self._err(player, f"Amount must be between 1 and {max_amount}.")
            return
        price = self.shop.price(category, item_id)  # fresh price: shop.json may have been reloaded
        if price is None:
            self._err(player, f"{self._pretty(item_id)} is no longer for sale.")
            self._open_shop_category(player, category)
            return
        self._buy(player, item_id, amount, price)
        self._open_shop_category(player, category)

    def _buy(self, player: Player, item_id: str, amount: int, price: float) -> None:
        """Give items first, then charge only for what actually fit in the inventory."""
        key = self._key(player)
        cost = round(amount * price, 2)
        if not self.accounts.has(key, cost):
            self._err(player, f"Insufficient funds: {self._fmt(cost)} needed, "
                              f"you have {self._fmt(self.accounts.balance(key))}.")
            return
        try:
            probe = ItemStack(item_id, 1)
            chunk = getattr(getattr(probe, "type", None), "max_stack_size", None) or 64
            pieces = []
            remaining = amount
            while remaining > 0:
                n = min(chunk, remaining)
                pieces.append(ItemStack(item_id, n))
                remaining -= n
        except Exception:  # invalid item id in shop.json
            self.logger.warning(f"shop.json has an invalid item id: {item_id}")
            self._err(player, f"{self._pretty(item_id)} is unavailable right now.")
            return
        leftover = player.inventory.add_item(*pieces)
        not_fitted = 0
        if leftover:
            values = leftover.values() if hasattr(leftover, "values") else leftover
            not_fitted = sum(stack.amount for stack in values)
        bought = amount - not_fitted
        if bought <= 0:
            self._err(player, "Your inventory is full.")
            return
        charge = round(bought * price, 2)
        self.accounts.withdraw(key, charge)
        msg = f"{ColorFormat.GREEN}Bought {bought}x {self._pretty(item_id)} for {self._fmt(charge)}."
        if not_fitted:
            msg += f" {ColorFormat.YELLOW}({not_fitted} didn't fit and wasn't charged.)"
        player.send_message(msg)

    def _cmd_worth(self, sender: CommandSender, args: list[str]) -> bool:
        count = 1
        if args:
            item_id = normalize_item_id(args[0])
        else:
            player = self._require_player(sender)
            if player is None:
                return True
            stack = self._held(player)
            if stack is None:
                self._err(sender, "Hold an item or specify one: /worth <item>")
                return True
            item_id, count = item_id_of(stack), stack.amount
        price = self.prices.price(item_id)
        if price is None:
            self._err(sender, f"{item_id} can't be sold (no price set).")
            return True
        msg = f"{ColorFormat.GOLD}{item_id}: {ColorFormat.YELLOW}{self._fmt(price)} each"
        if count > 1:
            msg += f"{ColorFormat.GRAY} ({count} = {self._fmt(price * count)})"
        sender.send_message(msg)
        return True

    # ------------------------------------------------------------------ admin commands
    def _cmd_addmoney(self, sender: CommandSender, args: list[str]) -> bool:
        if len(args) < 2:
            return False
        key = self._resolve(sender, args[0])
        amount = self._amount(sender, args[1]) if key else None
        if key is None or amount is None:
            return True
        new = self.accounts.deposit(key, amount)
        name = self.accounts.name_of(key)
        self._ok(sender, f"Added {self._fmt(amount)} to {name}. New balance: {self._fmt(new)}")
        self._notify(key, f"{ColorFormat.GREEN}You received {self._fmt(amount)}.")
        return True

    def _cmd_subtractmoney(self, sender: CommandSender, args: list[str]) -> bool:
        if len(args) < 2:
            return False
        key = self._resolve(sender, args[0])
        amount = self._amount(sender, args[1]) if key else None
        if key is None or amount is None:
            return True
        new = self.accounts.set_balance(key, self.accounts.balance(key) - amount)  # floors at 0
        name = self.accounts.name_of(key)
        self._ok(sender, f"Removed {self._fmt(amount)} from {name}. New balance: {self._fmt(new)}")
        self._notify(key, f"{ColorFormat.RED}{self._fmt(amount)} was removed from your balance.")
        return True

    def _cmd_setmoney(self, sender: CommandSender, args: list[str]) -> bool:
        if len(args) < 2:
            return False
        key = self._resolve(sender, args[0])
        amount = self._amount(sender, args[1], allow_zero=True) if key else None
        if key is None or amount is None:
            return True
        new = self.accounts.set_balance(key, amount)
        self._ok(sender, f"Set {self.accounts.name_of(key)}'s balance to {self._fmt(new)}.")
        self._notify(key, f"{ColorFormat.YELLOW}Your balance was set to {self._fmt(new)}.")
        return True

    def _cmd_transfermoney(self, sender: CommandSender, args: list[str]) -> bool:
        if len(args) < 3:
            return False
        src = self._resolve(sender, args[0])
        dst = self._resolve(sender, args[1]) if src else None
        amount = self._amount(sender, args[2]) if dst else None
        if src is None or dst is None or amount is None:
            return True
        if src == dst:
            self._err(sender, "Source and destination are the same account.")
            return True
        if not self.accounts.withdraw(src, amount):
            self._err(sender, f"{self.accounts.name_of(src)} only has {self._fmt(self.accounts.balance(src))}.")
            return True
        self.accounts.deposit(dst, amount)
        a, b = self.accounts.name_of(src), self.accounts.name_of(dst)
        self._ok(sender, f"Transferred {self._fmt(amount)} from {a} to {b}.")
        self._notify(src, f"{ColorFormat.RED}{self._fmt(amount)} was transferred from your account to {b}.")
        self._notify(dst, f"{ColorFormat.GREEN}You received {self._fmt(amount)} from {a}.")
        return True

    def _cmd_ecoreload(self, sender: CommandSender, args: list[str]) -> bool:
        self.settings = self._load_settings()
        self.accounts.starting_balance = float(self.settings["starting_balance"])
        count = self.prices.load()
        shop_count = self.shop.load()
        self._ok(sender, f"Reloaded config, {count} sell prices and {shop_count} shop items.")
        return True
